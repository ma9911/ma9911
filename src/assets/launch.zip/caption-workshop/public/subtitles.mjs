export const LIMITS = Object.freeze({ bytes: 2_000_000, cues: 5000, cueText: 10000 });
export function timestamp(value) {
  const match = /^(\d{2,}):(\d{2}):(\d{2})[,.](\d{3})$/.exec(value) || /^(\d{2}):(\d{2})\.(\d{3})$/.exec(value);
  if (!match) throw new Error('timestamp');
  const values = match.slice(1).map(Number);
  const [h,m,s,ms] = values.length === 4 ? values : [0,...values];
  if (m > 59 || s > 59) throw new Error('timestamp');
  const result = ((h*60+m)*60+s)*1000+ms;
  if (!Number.isSafeInteger(result)) throw new Error('timestamp');
  return result;
}
export function validate(cues) {
  if (!cues.length || cues.length > LIMITS.cues) throw new Error('cue-count');
  let lastEnd = 0;
  for (const cue of cues) {
    if (!Number.isSafeInteger(cue.start) || !Number.isSafeInteger(cue.end) || cue.start < 0 || cue.end <= cue.start) throw new Error('timing');
    if (cue.start < lastEnd) throw new Error('overlap');
    if (typeof cue.text !== 'string' || !cue.text.trim() || cue.text.length > LIMITS.cueText || /(?:^\s*\n|\n\s*$|\n\s*\n)/.test(cue.text) || /[\u0000-\u0008\u000B-\u001F\u007F]/.test(cue.text)) throw new Error('cue-text');
    lastEnd = cue.end;
  }
  return cues;
}
export function parse(input) {
  if (new TextEncoder().encode(input).length > LIMITS.bytes) throw new Error('file-size');
  const trimBlankLines = value => value.replace(/^(?:[ \t]*\n)+|(?:\n[ \t]*)+$/g, '');
  let text = trimBlankLines(input.replace(/^\uFEFF/, '').replace(/\r\n?/g,'\n'));
  if (text.startsWith('WEBVTT')) {
    if (!/^WEBVTT(?:\n|$)/.test(text)) throw new Error('unsupported');
    text = trimBlankLines(text.slice(6));
  }
  const blocks = text.split(/\n[ \t]*\n/);
  if (blocks.length > LIMITS.cues) throw new Error('cue-count');
  const cues = blocks.map(block => {
    const lines = block.split('\n');
    if (!lines[0].includes('-->')) lines.shift();
    const match = /^([^ ]+) --> ([^ ]+)$/.exec(lines.shift() || '');
    if (!match) throw new Error('unsupported');
    return {start:timestamp(match[1]),end:timestamp(match[2]),text:lines.join('\n')};
  });
  return validate(cues);
}
export function shift(cues, milliseconds) {
  if (!Number.isSafeInteger(milliseconds)) throw new Error('shift');
  return validate(cues.map(cue => ({...cue,start:cue.start+milliseconds,end:cue.end+milliseconds})));
}
function time(ms, separator) {
  const h=Math.floor(ms/3600000),m=Math.floor(ms/60000)%60,s=Math.floor(ms/1000)%60;
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}${separator}${String(ms%1000).padStart(3,'0')}`;
}
export function serialize(cues, format='srt') {
  validate(cues);
  if (!['srt','vtt'].includes(format)) throw new Error('format');
  const output = (format==='vtt'?'WEBVTT\n\n':'')+cues.map((cue,i)=>`${i+1}\n${time(cue.start,format==='srt'?',':'.')} --> ${time(cue.end,format==='srt'?',':'.')}\n${cue.text}`).join('\n\n')+'\n';
  if (new TextEncoder().encode(output).length > LIMITS.bytes) throw new Error('file-size');
  return output;
}
export function readingSpeed(cue) { return [...cue.text.replace(/\s/g,'')].length / ((cue.end-cue.start)/1000); }
