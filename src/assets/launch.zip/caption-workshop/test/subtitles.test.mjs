import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parse,serialize,shift,readingSpeed,LIMITS} from '../public/subtitles.mjs';
const srt='1\r\n00:00:01,250 --> 00:00:03,250\r\nHello, world!\r\n\r\n2\r\n00:00:04,000 --> 00:00:06,000\r\nПривет!';
test('SRT and VTT preserve text and milliseconds through roundtrips',()=>{const cues=parse(srt);assert.equal(cues[0].start,1250);for(const format of ['srt','vtt'])assert.deepEqual(parse(serialize(cues,format)),cues);});
test('VTT accepts minute timestamps, BOM and multiline text',()=>{assert.deepEqual(parse('\uFEFFWEBVTT\n\nalpha\n01:00.001 --> 01:03.000\nOne\nTwo'),[{start:60001,end:63000,text:'One\nTwo'}]);});
test('negative shift is atomic and boundary zero is allowed',()=>{const cues=parse(srt),original=structuredClone(cues);assert.equal(shift(cues,-1250)[0].start,0);assert.throws(()=>shift(cues,-1251),/timing/);assert.deepEqual(cues,original);assert.throws(()=>shift(cues,1.5),/shift/);});
test('invalid timing and overlaps are rejected rather than dropped',()=>{for(const input of ['1\n00:00:61,000 --> 00:01:02,000\nx','1\n00:00:03,000 --> 00:00:02,000\nx','1\n00:00:01,000 --> 00:00:04,000\nx\n\n2\n00:00:03,000 --> 00:00:05,000\ny'])assert.throws(()=>parse(input));});
test('cue settings, notes and empty lines are not silently discarded',()=>{for(const input of ['WEBVTT\n\nNOTE Hello','WEBVTT\n\n00:01.000 --> 00:02.000 align:start\nx',srt+'\n\nUnrecognised text'])assert.throws(()=>parse(input));});
test('HTML-looking subtitle text is preserved as text',()=>{const payload='<img src=x onerror=alert(1)> & <script>alert(2)</script>';assert.equal(parse(serialize([{start:0,end:1000,text:payload}]))[0].text,payload);});
test('caps and editorial reading-speed definition',()=>{assert.throws(()=>parse('x'.repeat(LIMITS.bytes+1)),/file-size/);assert.equal(readingSpeed({start:0,end:2000,text:'ab cd'}),2);assert.throws(()=>serialize([{start:0,end:1,text:'x'.repeat(LIMITS.cueText+1)}]),/cue-text/);});

test('SRT and VTT roundtrips preserve significant leading and trailing cue spaces',()=>{
 const cues=[{start:0,end:1000,text:'  Первая строка  \n\tВторая строка\t  '}];
 for(const format of ['srt','vtt'])assert.deepEqual(parse(serialize(cues,format)),cues);
});

test('serialization enforces the documented UTF-8 export limit',()=>{
 const cues=Array.from({length:100},(_,i)=>({start:i*2000,end:i*2000+1000,text:'я'.repeat(10000)}));
 assert.throws(()=>serialize(cues),/file-size/);
});

test('cue text with boundary empty lines cannot be exported as a different block structure',()=>{
 for(const text of ['\nHello','Hello\n',' \nHello','Hello\n\t'])
  assert.throws(()=>serialize([{start:0,end:1000,text}]),/cue-text/);
});
