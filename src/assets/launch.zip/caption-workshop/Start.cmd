@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 22 or newer and restart this launcher.
  pause
  exit /b 1
)
node server.mjs
if errorlevel 1 pause
