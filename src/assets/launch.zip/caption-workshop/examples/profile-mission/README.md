# Firefly Cinema — a runnable example

This is synthetic demonstration data for caption-workshop, curated for the explicitly fictional @ma9911 developer persona.

## Try it

Requires Node.js 22+. From the project root run:

```text
node examples/profile-mission/check.mjs
```

Load input.srt in Caption Workshop, shift by +250 ms and compare the exported subtitle file with shifted.srt.

Start the full local app using Start.cmd on Windows, or `node server.mjs`; open http://127.0.0.1:8803. The original README contains its complete instructions.

## A useful next change

Add a VTT version of the same scene and verify its timing with the parser.

The example, assertion script and documentation are new local additions. The application, original authors, LICENSE and existing Git history retain their attribution. The source ZIP contains no Git database; publish a separate repository from the original local Git project to retain its history.
