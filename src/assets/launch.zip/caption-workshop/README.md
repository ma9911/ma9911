# Caption Workshop

<img src="public/icon.svg" alt="Caption Workshop icon" width="112">

[English](README.md) · [Русский](README.ru.md) · [Español](README.es.md)

![JavaScript ES modules](https://img.shields.io/badge/JavaScript-ES%20modules-F7DF1E?logo=javascript&logoColor=black)
![Node.js 22+](https://img.shields.io/badge/Node.js-22%2B-339933?logo=nodedotjs&logoColor=white)
![Formats SRT / VTT](https://img.shields.io/badge/Formats-SRT%20%2F%20VTT-4472C4)
[![License MIT](https://img.shields.io/badge/License-MIT-22A669)](LICENSE)

A focused local editor for the final subtitle pass.

<details>
<summary>Contents</summary>

[Features](#readme-features) · [Technology stack](#readme-stack) · [Quick start](#readme-start) · [Limits](#readme-detail-01) · [Business pilot hypothesis](#readme-detail-02) · [Verification on 2026-10-29](#readme-detail-03) · [Author](#readme-author) · [License](#readme-license)

</details>

<a id="readme-preview"></a>

![caption-workshop interface](docs/images/preview.jpg)

Actual local interface with synthetic demonstration data.

<a id="readme-features"></a>

## Features

| Feature | Behavior |
| --- | --- |
| Plain subtitles | Read SRT/VTT with strict timing checks |
| Editing | Cue text, literal replacements and millisecond shift |
| Export | SRT/VTT downloads; no transcription or translation |

1. Open or paste a plain SRT / VTT file. The example button loads synthetic subtitles.
2. Edit individual cue text and start / end times. Shift all cues by integer milliseconds or apply a case-sensitive literal text replacement.
3. Inspect non-whitespace characters per second (CPS). This is editorial guidance, not a platform-specific compliance check.
4. Download SRT or VTT through the browser. The browser determines the destination and may ask permission.

The EN / RU / ES interface uses the browser language on first use, with an explicit selector. Only the language preference is saved in localStorage. Subtitle content stays in browser memory. No transcription, translation, upload, accounts or cloud calls are implemented.

<a id="readme-stack"></a>

## Technology stack

| Component | Source |
| --- | --- |
| Parser, validation, shifts and serialization | [public/subtitles.mjs](public/subtitles.mjs) |
| Browser editing, local downloads, localization | [public/app.mjs](public/app.mjs) |
| Buildless static server / CSP | [server.mjs](server.mjs) |
| Boundary and roundtrip tests | [test/subtitles.test.mjs](test/subtitles.test.mjs) |

<a id="readme-start"></a>

## Quick start

Install **Node.js 22 or later** separately. No `npm install` step.

| System | Command |
| --- | --- |
| Windows | Double-click `Start.cmd` or `Start.bat` |
| macOS | `sh Start.command` (or `chmod +x Start.command` once, then double-click) |
| Ubuntu | `sh start.sh` |
| Make, when installed | `make start` / `make test` |
| Any system with Node | `node server.mjs` / `node --test` |

Open **http://127.0.0.1:8803** after the launcher prints the address. Stop with Ctrl+C. To select another port, use `$env:PORT=8813; node server.mjs` in PowerShell or `PORT=8813 sh start.sh` in a POSIX shell. Scripts do not install software or configure startup services. Native macOS execution remains unverified; dated Windows/WSL Ubuntu checks are recorded below.

<a id="readme-detail-01"></a>

## Limits

- Maximum input: 2,000,000 UTF-8 bytes, 5,000 cues, 10,000 JavaScript characters per cue. Export is also capped at 2,000,000 bytes.
- Plain SRT and VTT cues only. VTT styles, NOTE / REGION blocks, cue settings and header metadata are rejected. Identifiers are regenerated on export. Inline markup remains literal in the editor; another subtitle player may interpret it.
- Negative timing, invalid intervals, overlaps and out-of-order cues are reported. Failed shift / replacement leaves the previous cue state intact. The editor does not automatically repair unsupported formats.
- No persistent document storage or undo history. Export before closing or refreshing. Loading a new source replaces the editor content.
- The server binds to IPv4 loopback with an exact asset allowlist and Host validation. It serves application assets only; no API receives subtitle data. This is a workstation tool, not a public multi-user service.


<a id="readme-detail-02"></a>

## Business pilot hypothesis

Offer subtitle cleanup as a small fixed-scope service to a video editor: one supplied subtitle file, reviewed timing and text, SRT / VTT delivery. Ask a potential client to test one short clip before setting a price. Demand, pricing and income are unverified; the tool does not generate customers or automatically proofread content.

<a id="readme-detail-03"></a>

## Verification on 2026-10-29

Windows and WSL Ubuntu: product tests and a real launcher start passed. macOS execution remains unverified. Browser checks used synthetic data; download buttons requested exports, but saving to the operating system Downloads folder was not verified.

<a id="readme-author"></a>

## Author

[d9911](https://github.com/d9911) · [d9911.org](https://d9911.org).

<a id="readme-license"></a>

## License

MIT for this project's original code: [LICENSE](LICENSE). Client subtitle content retains its own rights.
