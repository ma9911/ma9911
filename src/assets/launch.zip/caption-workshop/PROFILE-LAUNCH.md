# Source snapshot / Firefly Cinema

Project: caption-workshop. Curated for @ma9911, an explicitly fictional developer persona.

Original source HEAD: `b00775820ba83d53b50acd25388e5a9ac32e5ed5`. The existing README and LICENSE are preserved. Windows Explorer desktop.ini files are omitted from this distributable. Added synthetic examples are in examples/profile-mission.

Runtime: Node.js 22+. Start: `node server.mjs`. Demo check: `node examples/profile-mission/check.mjs`.

This source download is for trying the application. It excludes .git and commit emails. A separately published repository should use the original project's history.
