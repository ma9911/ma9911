import http from 'node:http';
import {readFile} from 'node:fs/promises';
const port=Number(process.env.PORT || 8803);
if (!Number.isInteger(port)||port<1||port>65535) throw new Error('PORT must be an integer from 1 to 65535');
const files=new Map([['/',['index.html','text/html; charset=utf-8']],['/app.mjs',['app.mjs','text/javascript; charset=utf-8']],['/subtitles.mjs',['subtitles.mjs','text/javascript; charset=utf-8']],['/style.css',['style.css','text/css; charset=utf-8']],['/icon.svg',['icon.svg','image/svg+xml']]]);
const server=http.createServer(async(req,res)=>{
  const host=req.headers.host;
  if (![ `127.0.0.1:${port}`, `localhost:${port}`].includes(host)) {res.writeHead(403);res.end('Forbidden host');return;}
  if (!['GET','HEAD'].includes(req.method)) {res.writeHead(405,{'Allow':'GET, HEAD'});res.end();return;}
  const item=files.get(req.url?.split('?')[0]);
  if (!item) {res.writeHead(404);res.end('Not found');return;}
  try {
    const bytes=await readFile(new URL(`public/${item[0]}`,import.meta.url));
    res.writeHead(200,{'Content-Type':item[1],'Content-Length':bytes.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; connect-src 'none'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"});res.end(req.method==='HEAD'?undefined:bytes);
  }catch {res.writeHead(500);res.end('Cannot read application asset');}
});
server.listen(port,'127.0.0.1',()=>console.log(`Caption Workshop: http://127.0.0.1:${port} — Ctrl+C to stop`));
