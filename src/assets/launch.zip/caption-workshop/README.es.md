# Caption Workshop

<img src="public/icon.svg" alt="Caption Workshop icon" width="112">

[English](README.md) · [Русский](README.ru.md) · [Español](README.es.md)

![JavaScript ES modules](https://img.shields.io/badge/JavaScript-ES%20modules-F7DF1E?logo=javascript&logoColor=black)
![Node.js 22+](https://img.shields.io/badge/Node.js-22%2B-339933?logo=nodedotjs&logoColor=white)
![Formats SRT / VTT](https://img.shields.io/badge/Formats-SRT%20%2F%20VTT-4472C4)
[![License MIT](https://img.shields.io/badge/License-MIT-22A669)](LICENSE)

Un editor local para la revisión final de subtítulos.

<details>
<summary>Contenido</summary>

[Funciones](#readme-features) · [Tecnologías](#readme-stack) · [Inicio rápido](#readme-start) · [Límites](#readme-detail-01) · [Hipótesis de piloto comercial](#readme-detail-02) · [Verificación del 2026-10-29](#readme-detail-03) · [Autor](#readme-author) · [Licencia](#readme-license)

</details>

<a id="readme-preview"></a>

![caption-workshop interface](docs/images/preview.jpg)

Interfaz local real con datos de demostración.

<a id="readme-features"></a>

## Funciones

| Función | Comportamiento |
| --- | --- |
| Subtítulos simples | Lee SRT/VTT con validación de tiempos |
| Edición | Texto, reemplazo literal y desplazamiento en milisegundos |
| Exportación | Descarga SRT/VTT; sin transcripción ni traducción |

Abre o pega un SRT / VTT simple. Edita texto e inicio / fin por entrada, desplaza todos los tiempos por milisegundos enteros o reemplaza texto literal distinguiendo mayúsculas. El ejemplo contiene subtítulos ficticios. CPS mide caracteres sin espacios por segundo; es orientación editorial, no validación de una plataforma. Exporta SRT / VTT: el navegador decide la carpeta y los permisos.

La interfaz EN / RU / ES utiliza inicialmente el idioma del navegador. El selector guarda solo el idioma en localStorage. Los subtítulos permanecen en la memoria de la pestaña. No hay transcripción, traducción, cuentas ni envío de subtítulos al servidor.

<a id="readme-stack"></a>

## Tecnologías

| Componente | Implementación | Fuente |
| --- | --- | --- |
| Analizador y exportación | Validación y serialización SRT / VTT | [public/subtitles.mjs](public/subtitles.mjs) |
| Interfaz del navegador | JavaScript / HTML / CSS | [public/app.mjs](public/app.mjs) |
| Servidor local | HTTP integrado de Node.js; recursos permitidos | [server.mjs](server.mjs) |

Analizador y exportación: [public/subtitles.mjs](public/subtitles.mjs). Editor, idiomas y descargas: [public/app.mjs](public/app.mjs). Servidor y CSP: [server.mjs](server.mjs). Pruebas de límites y conversión: [test/subtitles.test.mjs](test/subtitles.test.mjs).

<a id="readme-start"></a>

## Inicio rápido

Instala **Node.js 22+** por separado. No hace falta `npm install`.

| Sistema | Comando |
| --- | --- |
| Windows | Doble clic en `Start.cmd` o `Start.bat` |
| macOS | `sh Start.command`; para doble clic, primero `chmod +x Start.command` |
| Ubuntu | `sh start.sh` |
| Make, si está instalado | `make start` / `make test` |
| Cualquier sistema con Node | `node server.mjs` / `node --test` |

Abre **http://127.0.0.1:8803** después del mensaje del servidor. Detén con Ctrl+C. Puerto alternativo: `$env:PORT=8813; node server.mjs` en PowerShell o `PORT=8813 sh start.sh` en shell POSIX. Los scripts no instalan software ni configuran servicios. El arranque nativo de macOS sigue sin probarse; las pruebas Windows/WSL Ubuntu figuran abajo.

<a id="readme-detail-01"></a>

## Límites

- Hasta 2.000.000 bytes UTF-8, 5.000 entradas y 10.000 caracteres JavaScript por entrada. La exportación también se limita a 2.000.000 bytes.
- Solo SRT / VTT simples. Se rechazan estilos, NOTE / REGION, ajustes y metadatos de cabecera VTT. Los identificadores se regeneran al exportar. El marcado se muestra como texto; un reproductor externo puede interpretarlo.
- Tiempos negativos, intervalos inválidos, solapamientos y desorden producen errores. Un desplazamiento / reemplazo fallido conserva el estado anterior. No se reparan formatos automáticamente.
- Sin almacenamiento de documentos ni historial de deshacer. Exporta antes de cerrar o recargar. Cargar otro original reemplaza el editor.
- Servidor solo en IPv4 loopback, con lista de recursos permitidos y validación de Host. No hay API de subida. Es una herramienta local, no un servicio público multiusuario.

<a id="readme-detail-02"></a>

## Hipótesis de piloto comercial

Ofrecer a un editor de vídeo la revisión de un archivo suministrado: texto y tiempos revisados, entrega SRT / VTT. Acordar primero un clip breve y el alcance. Demanda, precio e ingresos no están verificados. La herramienta no capta clientes ni corrige el texto automáticamente.

<a id="readme-detail-03"></a>

## Verificación del 2026-10-29

Las pruebas y el arranque real mediante BAT/shell pasaron en Windows y WSL Ubuntu. La ejecución en macOS sigue sin verificarse. Las pruebas del navegador usaron datos de demostración; se solicitó la descarga, pero no se verificó el guardado en la carpeta Descargas del sistema.

<a id="readme-author"></a>

## Autor

[d9911](https://github.com/d9911) · [d9911.org](https://d9911.org).

<a id="readme-license"></a>

## Licencia

Código original del proyecto bajo MIT: [LICENSE](LICENSE). Los subtítulos de clientes conservan sus propios derechos.
